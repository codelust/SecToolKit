# TCP-UDP-Flood
Python3 TCP/UDP Flood script

Usage:

    python3 flood.py
